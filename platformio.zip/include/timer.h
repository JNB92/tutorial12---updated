#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

extern volatile uint8_t pb_debounced_state;

#endif
